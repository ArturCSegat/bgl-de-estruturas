#ifndef ITEM_C
#define ITEM_C
typedef struct {
	char nome[50];
	int quant;
} Item;
#endif
