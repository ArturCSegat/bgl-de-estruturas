#ifndef TECNICO_H
#define TECNICO_H
#include "lista.c"
typedef struct {
	char nome[50];
	NodeLista * chamados;

} Tecnico;
#endif
